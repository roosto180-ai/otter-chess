'use client';

import type { MatchRecord } from '@/lib/play/types';

export default function LobbySidebar({
  enginesReady,
  matchHistory,
  onChallengeClick,
  onAnalyzeClick,
  onEditorClick,
  onSetupClick,
  onLockedClick,
  loadGameForAnalysis,
}: {
  enginesReady: boolean;
  matchHistory: MatchRecord[];
  onChallengeClick: () => void;
  onAnalyzeClick: () => void;
  onEditorClick: () => void;
  onSetupClick: () => void;
  onLockedClick: () => void;
  loadGameForAnalysis: (input: string) => void;
}) {
  return (
    <div className="flex-grow flex flex-col min-h-0 divide-y divide-line">
      {/* Below lg this is trimmed to the single badge row: on a phone the
          controls column is only ~180px tall, and the heading plus blurb ate
          all of it, leaving the actions below the fold. The title and blurb
          are decoration — the buttons are the reason anyone is here. */}
      <div className="p-3 px-6 lg:p-6 lg:px-8 space-y-2.5 lg:space-y-4">
        <div className="flex items-center gap-2 font-mono text-[9px] text-pear tracking-[0.08em] uppercase">
          <span className="border border-pear px-1.5 py-0.5 font-bold">LOBBY</span>
          <span>Otter Chess Arena</span>
        </div>
        <h2 className="hidden lg:block font-space font-medium text-[18px] text-paper">Otter Arena</h2>
        <p className="hidden lg:block text-[11.5px] text-muted leading-relaxed">
          Configure your match variables, setup custom positions using the editor, or import notation files.
        </p>
      </div>

      {/* Lobby Play Game, Analyze, & Board Editor buttons */}
      <div className="p-4 px-6 lg:p-6 lg:px-8 space-y-2.5">
        {/* Every action below is gated on the engines being downloaded, so
            when they're missing the lobby leads with the way to get them —
            otherwise the whole panel is three dead buttons and the only cue
            is the status strip. */}
        {!enginesReady && (
          <button
            onClick={onSetupClick}
            className="w-full py-3 font-space text-[12px] tracking-wider uppercase font-semibold text-orange-950 bg-orange-400 border border-orange-400 hover:bg-orange-500 hover:border-orange-500 transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
          >
            <span>Set Up Engines</span>
            <span className="font-mono text-[10px] normal-case tracking-normal opacity-80">33MB</span>
          </button>
        )}

        {/* These stay real (non-disabled) buttons even when the engines
            aren't ready, so a click can surface a hint instead of doing
            nothing — an actual `disabled` attribute swallows the click. */}
        <button
          onClick={enginesReady ? onChallengeClick : onLockedClick}
          aria-disabled={!enginesReady}
          className={`w-full py-3 font-space text-[12px] tracking-wider uppercase font-semibold text-bg bg-pear border border-pear hover:bg-[#4d7524] hover:border-[#4d7524] transition-all flex items-center justify-center shadow-lg cursor-pointer ${!enginesReady ? 'opacity-50' : ''}`}
        >
          <span>Challenge Otter AI</span>
        </button>

        <button
          onClick={enginesReady ? onAnalyzeClick : onLockedClick}
          aria-disabled={!enginesReady}
          className={`w-full py-3 font-space text-[12px] tracking-wider uppercase font-semibold text-paper bg-bg border border-[#7a856f]/55 hover:border-pear hover:text-pear transition-all flex items-center justify-center shadow-lg cursor-pointer ${!enginesReady ? 'opacity-50' : ''}`}
        >
          <span>Analyze Game</span>
        </button>

        <button
          onClick={enginesReady ? onEditorClick : onLockedClick}
          aria-disabled={!enginesReady}
          className={`w-full py-3 font-space text-[12px] tracking-wider uppercase font-semibold text-paper bg-bg border border-[#7a856f]/55 hover:border-pear hover:text-pear transition-all flex items-center justify-center shadow-lg cursor-pointer ${!enginesReady ? 'opacity-50' : ''}`}
        >
          <span>Board Editor</span>
        </button>
      </div>

      {/* Match history list */}
      <div className="flex-grow p-4 px-6 lg:p-6 lg:px-8 flex flex-col min-h-0">
        <div className="block-label font-mono text-[9.5px] text-pear tracking-[0.12em] mb-3 uppercase font-bold shrink-0">
          Match History
        </div>
        {/* Below lg the whole sidebar is the scroll container, so this list
            runs at natural height instead of nesting a second scroller. */}
        {matchHistory.length > 0 ? (
          <div className="space-y-2 flex-grow lg:overflow-y-auto pr-1 lg:min-h-[240px]">
            {matchHistory.map((rec) => (
              <div
                key={rec.id}
                onClick={() => rec.pgn && loadGameForAnalysis(rec.pgn)}
                title={rec.pgn ? 'Analyze this game' : undefined}
                className={`group p-2 border border-line bg-bg/50 rounded-[3px] text-[10.5px] font-mono flex justify-between items-center ${rec.pgn ? 'cursor-pointer hover:border-pear/60 hover:bg-pear-tint/5' : ''} transition-all`}
              >
                <div>
                  <div className="font-bold text-paper flex items-center gap-1.5">
                    vs Otter ({rec.opponentElo})
                    {rec.pgn && (
                      <span className="text-pear opacity-0 group-hover:opacity-100 transition-opacity text-[9px] normal-case font-normal">Analyze &rarr;</span>
                    )}
                  </div>
                  <div className="text-[9px] text-muted">{rec.date} • {rec.movesCount} moves</div>
                </div>
                <span className={`px-2 py-0.5 rounded-[2px] font-bold uppercase text-[9px] shrink-0 ${
                  rec.result === 'win' ? 'bg-pear-tint/15 text-pear border border-pear/30' :
                  rec.result === 'loss' ? 'bg-red-500/10 text-red-500 border border-red-500/20' :
                  'bg-paper/10 text-muted border border-[#7a856f]/30'
                }`}>
                  {rec.result}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-xs text-muted italic text-center py-6 border border-dashed border-[#7a856f]/30 rounded-[3px]">
            No matches completed yet.
          </div>
        )}
      </div>
    </div>
  );
}
